# Property Dashboard

This is a React + TypeScript based Property Listing Dashboard.